# Data Dictionary

## Overview

This section provides comprehensive definitions and specifications for all data fields used in the Radiant1 PMS API. The data dictionary serves as a reference for implementing correct data formats and validations.

## General Data Types

### Date and Time Formats
| Field | Format | Example | Description |
|-------|--------|---------|-------------|
| Date | YYYY-MM-DD | 2024-01-15 | ISO 8601 date format |
| DateTime | YYYY-MM-DDTHH:mm:ssZ | 2024-01-15T14:30:00Z | ISO 8601 datetime with UTC timezone |
| System Date | YYYY-MM-DD | 2024-01-15 | Internal system date format |
| System DateTime | YYYY-MM-DD HH:mm:ss | 2024-01-15 14:30:00 | Internal system datetime format |

### Currency Codes
- **Format**: ISO 4217 3-letter currency codes
- **Examples**: USD, EUR, GBP, JPY, AUD, CAD
- **Validation**: Must be uppercase and exactly 3 characters

### Country Codes
- **Format**: ISO 3166-1 alpha-3 country codes
- **Examples**: USA, GBR, DEU, JPN, AUS, CAN
- **Validation**: Must be uppercase and exactly 3 characters

## Booking Data Models

### BookingDto

| Field | Data Type | Required | Validation | Description |
|-------|-----------|----------|------------|-------------|
| `hotelCode` | string | Yes | Not empty, max 50 chars | Unique hotel identifier |
| `reference` | string | Yes | Not empty, max 100 chars | Unique reservation reference |
| `bookingDate` | datetime (ISO 8601) | Yes | Valid datetime, not future | Date when booking was created |
| `additionalNote` | string | Yes | Max 1000 chars | Additional booking notes |
| `lastUpdate` | datetime (ISO 8601) | Yes | Valid datetime, not before bookingDate | Last modification timestamp |
| `bookingSourceCode` | string | Yes | Not empty, max 50 chars | Booking source identifier |
| `marketSegmentCode` | string | Yes | Not empty, max 50 chars | Market segment identifier |
| `isHotelCollect` | boolean | Yes | true or false | Hotel collect payment flag |
| `reservationRooms` | array[RoomReservationDto] | Yes | At least 1 room | Array of room reservations |

### RoomReservationDto

| Field | Data Type | Required | Validation | Description |
|-------|-----------|----------|------------|-------------|
| `roomReference` | string | Yes | Not empty, max 50 chars | Unique room reference |
| `roomTypeCode` | string | Yes | Not empty, max 50 chars | Room type identifier |
| `ratePlanCode` | string | Yes | Not empty, max 50 chars | Rate plan identifier |
| `status` | enum | Yes | Valid room status | Room status (see enums) |
| `arrival` | datetime (ISO 8601) | Yes | Valid datetime, before departure | Check-in date and time |
| `departure` | datetime (ISO 8601) | Yes | Valid datetime, after arrival | Check-out date and time |
| `adult` | integer | Yes | Min 1, Max 99 | Number of adult guests |
| `child` | integer | Yes | Min 0, Max 99 | Number of child guests |
| `isComplimentary` | boolean | Yes | true or false | Complimentary stay flag |
| `isHouseUse` | boolean | Yes | true or false | House use flag |
| `guests` | array[GuestDto] | Yes | At least 1 guest | Array of guest information |
| `rates` | array[RateDto] | Yes | At least 1 rate | Array of rate information |

### GuestDto

| Field | Data Type | Required | Validation | Description |
|-------|-----------|----------|------------|-------------|
| `firstName` | string | Yes | Not empty, max 100 chars | Guest first name |
| `lastName` | string | Yes | Not empty, max 100 chars | Guest last name |
| `birthDate` | date (ISO 8601) | Yes | Valid date, not future | Guest birthdate |
| `gender` | string | Yes | max 20 chars | Guest gender (male, female, other) |
| `address` | string | Yes | Max 500 chars | Street address |
| `city` | string | Yes | Max 100 chars | City name |
| `zipCode` | string | Yes | Max 20 chars | Postal/ZIP code |
| `country` | string | No | ISO 3166-1 alpha-3, uppercase | Country code (optional) |
| `nationality` | string | No | ISO 3166-1 alpha-3, uppercase | Nationality code (optional) |
| `phoneNumber` | string | Yes | Max 50 chars, E.164 format preferred | Phone number |
| `email` | string | Yes | Valid email format | Email address |
| `isMainGuest` | boolean | Yes | true or false | Main guest flag |

### RateDto

| Field | Data Type | Required | Validation | Description |
|-------|-----------|----------|------------|-------------|
| `packageCode` | string | Yes | Not empty, max 50 chars | Package identifier |
| `packageName` | string | Yes | Not empty, max 100 chars | Package description |
| `chargingDateFrom` | datetime (ISO 8601) | Yes | Valid datetime | Charge period start |
| `chargingDateTo` | datetime (ISO 8601) | Yes | Valid datetime, after from | Charge period end |
| `isRoomRevenue` | boolean | Yes | true or false | Room revenue flag |
| `price` | decimal | Yes | Min 0, 2 decimal places | Base price amount |
| `tax` | decimal | Yes | Min 0, 2 decimal places | Tax amount |
| `serviceCharge` | decimal | Yes | Min 0, 2 decimal places | Service charge amount |
| `commission` | decimal | Yes | Min 0, 2 decimal places | Commission amount |
| `currency` | string | Yes | ISO 4217, 3 uppercase chars | Currency code |

## Statistics Data Models

### StatisticDto

| Field | Data Type | Required | Validation | Description |
|-------|-----------|----------|------------|-------------|
| `hotelCode` | string | Yes | Not empty, max 50 chars | Unique hotel identifier |
| `data` | array[StatisticDataDto] | Yes | At least 1 entry | Statistics data entries |

### StatisticDataDto

| Field | Data Type | Required | Validation | Description |
|-------|-----------|----------|------------|-------------|
| `date` | date (YYYY-MM-DD) | Yes | Valid date format | Statistics date |
| `roomTypeCode` | string | Yes | Not empty, max 50 chars | Room type identifier |
| `ratePlanCode` | string | Yes | Not empty, max 50 chars | Rate plan identifier |
| `marketSegmentCode` | string | Yes | Not empty, max 50 chars | Market segment identifier |
| `bookingSourceCode` | string | Yes | Not empty, max 50 chars | Booking source identifier |
| `roomSold` | integer | Yes | Min 0 | Number of rooms sold |
| `cancellation` | integer | Yes | Min 0 | Number of cancellations |
| `noOfBookings` | integer | Yes | Min 0 | Number of bookings |
| `totalRevenue` | decimal | Yes | Min 0, 2 decimal places | Total revenue |
| `totalRoomRevenue` | decimal | Yes | Min 0, 2 decimal places | Total room revenue |
| `totalNonRoomRevenue` | decimal | Yes | Min 0, 2 decimal places | Total non-room revenue |
| `roomRevenue` | decimal | Yes | Min 0, 2 decimal places | Room revenue |
| `roomRevenueTax` | decimal | Yes | Min 0, 2 decimal places | Room revenue tax |
| `roomRevenueCommission` | decimal | Yes | Min 0, 2 decimal places | Room revenue commission |
| `roomRevenueServiceCharge` | decimal | Yes | Min 0, 2 decimal places | Room revenue service charge |
| `nonRoomRevenue` | decimal | Yes | Min 0, 2 decimal places | Non-room revenue |
| `nonRoomRevenueTax` | decimal | Yes | Min 0, 2 decimal places | Non-room revenue tax |
| `nonRoomRevenueCommission` | decimal | Yes | Min 0, 2 decimal places | Non-room revenue commission |
| `nonRoomRevenueServiceCharge` | decimal | Yes | Min 0, 2 decimal places | Non-room revenue service charge |

## Enumerations

### Room Status (ROOM_STATUS)
| Value | Description | Business Logic |
|-------|-------------|----------------|
| `reserve` | Reservation on hold | Can be modified |
| `confirm` | Confirmed reservation | Can be modified until check-in |
| `check_in` | Guest checked in | Limited modifications allowed |
| `check_out` | Guest checked out | Cannot be modified |
| `cancelled` | Reservation cancelled | Cannot be reinstated easily |
| `no_show` | Guest did not arrive | Treated as cancellation |

### Age Qualifying Codes (AGE_QUALIFYING_CODE)
| Value | Description | Typical Age Range |
|-------|-------------|------------------|
| `10` | Adult | 18+ years |
| `8` | Child | 2-17 years |
| `7` | Infant | 0-1 years |

### Statistic Category Codes (STATISTIC_CATEGORY_CODE)
| Code | Context | Description |
|-------|---------|-------------|
| `1` | MARKET_SEGMENT | Market segment based statistics |
| `2` | BOOKING_SOURCE | Booking source based statistics |
| `3` | ROOM_TYPE | Room type based statistics |
| `4` | RATE_PLAN | Rate plan based statistics |
| `11` | ROOM_SOLD | Number of rooms sold |
| `9` | REVENUE | Revenue statistics |
| `14` | CANCELLATION | Cancellation statistics |
| `10` | NO_OF_BOOKINGS | Number of bookings statistics |

### SOAP Request Types (SOAP_REQUEST_TYPE)
| Value | Description |
|-------|-------------|
| `OTA_HotelResNotifRQ` | Hotel reservation notification |
| `OTA_HotelStatsNotifRQ` | Hotel statistics notification |
| `OTA_PingRQ` | Ping/health check |
| `OTA_HotelInvCountNotifRQ` | Inventory count notification |

## Field Relationships and Constraints

### Business Logic Constraints

1. **Reservation Validations**
   - `bookingDate` ≤ `lastUpdate`
   - `arrival` < `departure`
   - Exactly one `isMainGuest = true` per room
   - `isComplimentary` and `isHouseUse` cannot both be true
   - Room references must be unique within reservation

2. **Rate Coverage Requirements**
   - Rates must cover entire stay period
   - At least one `isRoomRevenue = true` rate per night
   - Charging dates must be within stay dates
   - Package codes must be unique per charging date

3. **Guest Validations**
   - `birthDate` must not be in the future
   - Email format must be valid
   - Phone number format recommended E.164

4. **Statistics Validations**
   - All monetary values must be non-negative
   - Date format must be YYYY-MM-DD
   - Logical consistency in revenue calculations

### Data Type Specifications

#### Decimal Values
- **Precision**: 2 decimal places for all monetary amounts
- **Range**: 0.00 to 999999.99
- **Format**: Use decimal point, no commas
- **Examples**: 150.00, 29.99, 1000.50

#### Integer Values
- **Range**: 0 to 2147483647 (32-bit signed integer)
- **No decimal places**
- **Examples**: 1, 25, 100

#### String Values
- **Encoding**: UTF-8
- **Case Sensitivity**: Usually case-insensitive (depends on field)
- **Trimming**: Leading/trailing whitespace trimmed automatically
- **Special Characters**: XML/JSON encoded when necessary

#### Boolean Values
- **Format**: true/false (JSON), true/false (XML)
- **Default**: false if not specified
- **Null Handling**: Required fields cannot be null

## Error Reference

### Validation Error Messages

| Error Code | Message | Field | Resolution |
|------------|---------|-------|------------|
| INVALID_DATE_FORMAT | Date must be in YYYY-MM-DD format | date | Use correct date format |
| INVALID_DATETIME_FORMAT | DateTime must be ISO 8601 format | bookingDate, lastUpdate | Use ISO 8601 format |
| INVALID_CURRENCY_CODE | Currency must be 3 uppercase letters | currency | Use valid ISO 4217 code |
| INVALID_COUNTRY_CODE | Country must be 3 uppercase letters | country, nationality | Use valid ISO 3166-1 code |
| INVALID_EMAIL_FORMAT | Email format is invalid | email | Use valid email format |
| INVALID_PHONE_FORMAT | Phone format is invalid | phoneNumber | Use E.164 format |
| REQUIRED_FIELD_MISSING | Required field is missing | Various | Include all required fields |
| FIELD_TOO_LONG | Field exceeds maximum length | Various | Check maximum length limits |
| INVALID_ROOM_STATUS | Invalid room status value | status | Use valid room status values |

## Data Migration Notes

### From PMS to API

1. **Date Conversion**
   - Convert local timezone to UTC for datetime fields
   - Format dates as ISO 8601

2. **Code Mapping**
   - Map internal room type codes to API codes
   - Map internal rate plan codes to API codes
   - Map internal market segment codes to API codes

3. **Currency Handling**
   - Ensure all amounts are in specified currency
   - Convert to 2 decimal places
   - Use appropriate rounding rules

4. **Guest Information**
   - Split full names into first/last names
   - Validate email addresses
   - Format phone numbers internationally

### Best Practices

1. **Data Consistency**
   - Use consistent codes across all API calls
   - Maintain reference data mapping tables
   - Validate data before sending

2. **Error Handling**
   - Log validation errors locally
   - Implement retry logic for transient failures
   - Store failed requests for manual review

3. **Performance**
   - Batch multiple rooms in single reservation
   - Use appropriate request frequency
   - Monitor API response times

4. **Security**
   - Securely store authentication credentials
   - Validate input data to prevent injection
   - Use HTTPS for all communications