# API Examples

## Overview

This section provides comprehensive examples for all API endpoints and scenarios. These examples include complete request/response payloads, error cases, and integration patterns.

## REST API Examples

### Booking API Examples

#### Example 1: Simple Booking Request
**Scenario**: New reservation for one room with two guests

```http
POST /bookings
Content-Type: application/json
Accept: application/json

{
  "hotelCode": "HOTEL123",
  "reference": "RES-2024-001",
  "bookingDate": "2024-01-15T10:30:00Z",
  "additionalNote": "Guest prefers high floor, late arrival expected",
  "lastUpdate": "2024-01-15T14:30:00Z",
  "bookingSourceCode": "WEBSITE",
  "marketSegmentCode": "LEISURE",
  "isHotelCollect": true,
  "reservationRooms": [
    {
      "roomReference": "ROOM-001",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "BAR",
      "status": "confirm",
      "arrival": "2024-02-01T15:00:00Z",
      "departure": "2024-02-03T11:00:00Z",
      "adult": 2,
      "child": 0,
      "isComplimentary": false,
      "isHouseUse": false,
      "guests": [
        {
          "firstName": "John",
          "lastName": "Smith",
          "birthDate": "1985-05-15T00:00:00Z",
          "gender": "male",
          "address": "123 Main Street",
          "city": "New York",
          "zipCode": "10001",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0123",
          "email": "john.smith@example.com",
          "isMainGuest": true
        }
      ],
      "rates": [
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-02-01T00:00:00Z",
          "chargingDateTo": "2024-02-01T00:00:00Z",
          "isRoomRevenue": true,
          "price": 200.00,
          "tax": 20.00,
          "serviceCharge": 15.00,
          "commission": 0.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-02-02T00:00:00Z",
          "chargingDateTo": "2024-02-02T00:00:00Z",
          "isRoomRevenue": true,
          "price": 200.00,
          "tax": 20.00,
          "serviceCharge": 15.00,
          "commission": 0.00,
          "currency": "USD"
        }
      ]
    }
  ]
}
```

**Response**:
```json
{
  "success": "SUCCESS",
  "message": "success"
}
```

#### Example 2: Multi-Room Booking with Children
**Scenario**: Family booking with 2 rooms, adults and children

```json
{
  "hotelCode": "HOTEL123",
  "reference": "RES-2024-002",
  "bookingDate": "2024-01-16T09:15:00Z",
  "additionalNote": "Connecting rooms requested, crib needed for infant",
  "lastUpdate": "2024-01-16T09:15:00Z",
  "bookingSourceCode": "OTA",
  "marketSegmentCode": "FAMILY",
  "isHotelCollect": false,
  "reservationRooms": [
    {
      "roomReference": "ROOM-101",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "FAMILY",
      "status": "confirm",
      "arrival": "2024-03-15T16:00:00Z",
      "departure": "2024-03-20T11:00:00Z",
      "adult": 2,
      "child": 2,
      "isComplimentary": false,
      "isHouseUse": false,
      "guests": [
        {
          "firstName": "Robert",
          "lastName": "Johnson",
          "birthDate": "1980-03-10T00:00:00Z",
          "gender": "male",
          "address": "456 Oak Avenue",
          "city": "Los Angeles",
          "zipCode": "90001",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0456",
          "email": "robert.johnson@example.com",
          "isMainGuest": true
        },
        {
          "firstName": "Mary",
          "lastName": "Johnson",
          "birthDate": "1982-07-22T00:00:00Z",
          "gender": "female",
          "address": "456 Oak Avenue",
          "city": "Los Angeles",
          "zipCode": "90001",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0457",
          "email": "mary.johnson@example.com",
          "isMainGuest": false
        },
        {
          "firstName": "Emma",
          "lastName": "Johnson",
          "birthDate": "2010-05-12T00:00:00Z",
          "gender": "female",
          "address": "456 Oak Avenue",
          "city": "Los Angeles",
          "zipCode": "90001",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0458",
          "email": "emma.johnson@example.com",
          "isMainGuest": false
        },
        {
          "firstName": "Lucas",
          "lastName": "Johnson",
          "birthDate": "2014-09-03T00:00:00Z",
          "gender": "male",
          "address": "456 Oak Avenue",
          "city": "Los Angeles",
          "zipCode": "90001",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0459",
          "email": "lucas.johnson@example.com",
          "isMainGuest": false
        }
      ],
      "rates": [
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-15T00:00:00Z",
          "chargingDateTo": "2024-03-15T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-16T00:00:00Z",
          "chargingDateTo": "2024-03-16T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-17T00:00:00Z",
          "chargingDateTo": "2024-03-17T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-18T00:00:00Z",
          "chargingDateTo": "2024-03-18T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-19T00:00:00Z",
          "chargingDateTo": "2024-03-19T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        }
      ]
    },
    {
      "roomReference": "ROOM-102",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "FAMILY",
      "status": "confirm",
      "arrival": "2024-03-15T16:00:00Z",
      "departure": "2024-03-20T11:00:00Z",
      "adult": 2,
      "child": 0,
      "isComplimentary": false,
      "isHouseUse": false,
      "guests": [
        {
          "firstName": "Grandma",
          "lastName": "Johnson",
          "birthDate": "1955-11-30T00:00:00Z",
          "gender": "female",
          "address": "456 Oak Avenue",
          "city": "Los Angeles",
          "zipCode": "90001",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0460",
          "email": "grandma.johnson@example.com",
          "isMainGuest": true
        }
      ],
      "rates": [
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-15T00:00:00Z",
          "chargingDateTo": "2024-03-15T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-16T00:00:00Z",
          "chargingDateTo": "2024-03-16T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-17T00:00:00Z",
          "chargingDateTo": "2024-03-17T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-18T00:00:00Z",
          "chargingDateTo": "2024-03-18T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        },
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-03-19T00:00:00Z",
          "chargingDateTo": "2024-03-19T00:00:00Z",
          "isRoomRevenue": true,
          "price": 250.00,
          "tax": 25.00,
          "serviceCharge": 20.00,
          "commission": 25.00,
          "currency": "USD"
        }
      ]
    }
  ]
}
```

#### Example 3: Day Use Booking
**Scenario**: Same-day meeting room booking

```json
{
  "hotelCode": "HOTEL123",
  "reference": "RES-2024-003",
  "bookingDate": "2024-01-17T08:00:00Z",
  "additionalNote": "Day use meeting, needs projector setup",
  "lastUpdate": "2024-01-17T08:00:00Z",
  "bookingSourceCode": "CORPORATE",
  "marketSegmentCode": "BUSINESS",
  "isHotelCollect": true,
  "reservationRooms": [
    {
      "roomReference": "ROOM-MEETING-01",
      "roomTypeCode": "MEETING",
      "ratePlanCode": "DAY_USE",
      "status": "confirm",
      "arrival": "2024-01-20T09:00:00Z",
      "departure": "2024-01-20T18:00:00Z",
      "adult": 5,
      "child": 0,
      "isComplimentary": false,
      "isHouseUse": false,
      "guests": [
        {
          "firstName": "Michael",
          "lastName": "Chen",
          "birthDate": "1975-02-28T00:00:00Z",
          "gender": "male",
          "address": "789 Business Park",
          "city": "San Francisco",
          "zipCode": "94105",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0789",
          "email": "michael.chen@company.com",
          "isMainGuest": true
        }
      ],
      "rates": [
        {
          "packageCode": "DU",
          "packageName": "Day Use Rate",
          "chargingDateFrom": "2024-01-20T00:00:00Z",
          "chargingDateTo": "2024-01-20T00:00:00Z",
          "isRoomRevenue": true,
          "price": 500.00,
          "tax": 50.00,
          "serviceCharge": 40.00,
          "commission": 0.00,
          "currency": "USD"
        }
      ]
    }
  ]
}
```

#### Example 4: Complimentary Stay
**Scenario**: Loyalty reward complimentary night

```json
{
  "hotelCode": "HOTEL123",
  "reference": "RES-2024-004",
  "bookingDate": "2024-01-18T11:00:00Z",
  "additionalNote": "Loyalty reward complimentary night, guest prefers suite",
  "lastUpdate": "2024-01-18T11:00:00Z",
  "bookingSourceCode": "LOYALTY",
  "marketSegmentCode": "REWARD",
  "isHotelCollect": true,
  "reservationRooms": [
    {
      "roomReference": "ROOM-SUITE-001",
      "roomTypeCode": "SUITE",
      "ratePlanCode": "COMP",
      "status": "confirm",
      "arrival": "2024-02-14T15:00:00Z",
      "departure": "2024-02-16T11:00:00Z",
      "adult": 2,
      "child": 0,
      "isComplimentary": true,
      "isHouseUse": false,
      "guests": [
        {
          "firstName": "Sarah",
          "lastName": "Williams",
          "birthDate": "1990-04-08T00:00:00Z",
          "gender": "female",
          "address": "321 Premium Way",
          "city": "Chicago",
          "zipCode": "60601",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0321",
          "email": "sarah.williams@example.com",
          "isMainGuest": true
        }
      ],
      "rates": [
        {
          "packageCode": "COMP",
          "packageName": "Complimentary Night",
          "chargingDateFrom": "2024-02-14T00:00:00Z",
          "chargingDateTo": "2024-02-14T00:00:00Z",
          "isRoomRevenue": false,
          "price": 0.00,
          "tax": 0.00,
          "serviceCharge": 0.00,
          "commission": 0.00,
          "currency": "USD"
        },
        {
          "packageCode": "COMP",
          "packageName": "Complimentary Night",
          "chargingDateFrom": "2024-02-15T00:00:00Z",
          "chargingDateTo": "2024-02-15T00:00:00Z",
          "isRoomRevenue": false,
          "price": 0.00,
          "tax": 0.00,
          "serviceCharge": 0.00,
          "commission": 0.00,
          "currency": "USD"
        }
      ]
    }
  ]
}
```

### Statistics API Examples

#### Example 1: Daily Statistics by Room Type
**Scenario**: Complete daily breakdown by room type

```json
{
  "hotelCode": "HOTEL123",
  "data": [
    {
      "date": "2024-01-15",
      "roomTypeCode": "STANDARD",
      "ratePlanCode": "BAR",
      "marketSegmentCode": "TRANSIENT",
      "bookingSourceCode": "WEBSITE",
      "roomSold": 45,
      "cancellation": 3,
      "noOfBookings": 25,
      "totalRevenue": 6750.00,
      "totalRoomRevenue": 5400.00,
      "totalNonRoomRevenue": 1350.00,
      "roomRevenue": 5400.00,
      "roomRevenueTax": 540.00,
      "roomRevenueCommission": 270.00,
      "roomRevenueServiceCharge": 135.00,
      "nonRoomRevenue": 1350.00,
      "nonRoomRevenueTax": 135.00,
      "nonRoomRevenueCommission": 67.50,
      "nonRoomRevenueServiceCharge": 33.75
    },
    {
      "date": "2024-01-15",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "BAR",
      "marketSegmentCode": "TRANSIENT",
      "bookingSourceCode": "WEBSITE",
      "roomSold": 28,
      "cancellation": 2,
      "noOfBookings": 18,
      "totalRevenue": 5600.00,
      "totalRoomRevenue": 4900.00,
      "totalNonRoomRevenue": 700.00,
      "roomRevenue": 4900.00,
      "roomRevenueTax": 490.00,
      "roomRevenueCommission": 245.00,
      "roomRevenueServiceCharge": 122.50,
      "nonRoomRevenue": 700.00,
      "nonRoomRevenueTax": 70.00,
      "nonRoomRevenueCommission": 35.00,
      "nonRoomRevenueServiceCharge": 17.50
    },
    {
      "date": "2024-01-15",
      "roomTypeCode": "SUITE",
      "ratePlanCode": "CORPORATE",
      "marketSegmentCode": "CORPORATE",
      "bookingSourceCode": "CORPORATE",
      "roomSold": 8,
      "cancellation": 1,
      "noOfBookings": 6,
      "totalRevenue": 2400.00,
      "totalRoomRevenue": 2000.00,
      "totalNonRoomRevenue": 400.00,
      "roomRevenue": 2000.00,
      "roomRevenueTax": 200.00,
      "roomRevenueCommission": 200.00,
      "roomRevenueServiceCharge": 100.00,
      "nonRoomRevenue": 400.00,
      "nonRoomRevenueTax": 40.00,
      "nonRoomRevenueCommission": 20.00,
      "nonRoomRevenueServiceCharge": 10.00
    }
  ]
}
```

#### Example 2: Group Statistics by Market Segment
**Scenario**: Aggregated data by market segment

```json
{
  "hotelCode": "HOTEL123",
  "data": [
    {
      "date": "2024-01-15",
      "roomTypeCode": "ALL",
      "ratePlanCode": "ALL",
      "marketSegmentCode": "TRANSIENT",
      "bookingSourceCode": "ALL",
      "roomSold": 65,
      "cancellation": 4,
      "noOfBookings": 38,
      "totalRevenue": 9750.00,
      "totalRoomRevenue": 8250.00,
      "totalNonRoomRevenue": 1500.00,
      "roomRevenue": 8250.00,
      "roomRevenueTax": 825.00,
      "roomRevenueCommission": 412.50,
      "roomRevenueServiceCharge": 206.25,
      "nonRoomRevenue": 1500.00,
      "nonRoomRevenueTax": 150.00,
      "nonRoomRevenueCommission": 75.00,
      "nonRoomRevenueServiceCharge": 37.50
    },
    {
      "date": "2024-01-15",
      "roomTypeCode": "ALL",
      "ratePlanCode": "ALL",
      "marketSegmentCode": "GROUP",
      "bookingSourceCode": "ALL",
      "roomSold": 30,
      "cancellation": 0,
      "noOfBookings": 2,
      "totalRevenue": 4500.00,
      "totalRoomRevenue": 3900.00,
      "totalNonRoomRevenue": 600.00,
      "roomRevenue": 3900.00,
      "roomRevenueTax": 390.00,
      "roomRevenueCommission": 195.00,
      "roomRevenueServiceCharge": 97.50,
      "nonRoomRevenue": 600.00,
      "nonRoomRevenueTax": 60.00,
      "nonRoomRevenueCommission": 30.00,
      "nonRoomRevenueServiceCharge": 15.00
    },
    {
      "date": "2024-01-15",
      "roomTypeCode": "ALL",
      "ratePlanCode": "ALL",
      "marketSegmentCode": "CORPORATE",
      "bookingSourceCode": "ALL",
      "roomSold": 15,
      "cancellation": 1,
      "noOfBookings": 8,
      "totalRevenue": 3000.00,
      "totalRoomRevenue": 2600.00,
      "totalNonRoomRevenue": 400.00,
      "roomRevenue": 2600.00,
      "roomRevenueTax": 260.00,
      "roomRevenueCommission": 260.00,
      "roomRevenueServiceCharge": 130.00,
      "nonRoomRevenue": 400.00,
      "nonRoomRevenueTax": 40.00,
      "nonRoomRevenueCommission": 20.00,
      "nonRoomRevenueServiceCharge": 10.00
    }
  ]
}
```

#### Example 3: Multi-Day Statistics
**Scenario**: Statistics for multiple days

```json
{
  "hotelCode": "HOTEL123",
  "data": [
    {
      "date": "2024-01-15",
      "roomTypeCode": "STANDARD",
      "ratePlanCode": "BAR",
      "marketSegmentCode": "TRANSIENT",
      "bookingSourceCode": "WEBSITE",
      "roomSold": 45,
      "cancellation": 3,
      "noOfBookings": 25,
      "totalRevenue": 6750.00,
      "totalRoomRevenue": 5400.00,
      "totalNonRoomRevenue": 1350.00,
      "roomRevenue": 5400.00,
      "roomRevenueTax": 540.00,
      "roomRevenueCommission": 270.00,
      "roomRevenueServiceCharge": 135.00,
      "nonRoomRevenue": 1350.00,
      "nonRoomRevenueTax": 135.00,
      "nonRoomRevenueCommission": 67.50,
      "nonRoomRevenueServiceCharge": 33.75
    },
    {
      "date": "2024-01-16",
      "roomTypeCode": "STANDARD",
      "ratePlanCode": "BAR",
      "marketSegmentCode": "TRANSIENT",
      "bookingSourceCode": "WEBSITE",
      "roomSold": 48,
      "cancellation": 2,
      "noOfBookings": 27,
      "totalRevenue": 7200.00,
      "totalRoomRevenue": 5760.00,
      "totalNonRoomRevenue": 1440.00,
      "roomRevenue": 5760.00,
      "roomRevenueTax": 576.00,
      "roomRevenueCommission": 288.00,
      "roomRevenueServiceCharge": 144.00,
      "nonRoomRevenue": 1440.00,
      "nonRoomRevenueTax": 144.00,
      "nonRoomRevenueCommission": 72.00,
      "nonRoomRevenueServiceCharge": 36.00
    },
    {
      "date": "2024-01-17",
      "roomTypeCode": "STANDARD",
      "ratePlanCode": "BAR",
      "marketSegmentCode": "TRANSIENT",
      "bookingSourceCode": "WEBSITE",
      "roomSold": 42,
      "cancellation": 4,
      "noOfBookings": 22,
      "totalRevenue": 6300.00,
      "totalRoomRevenue": 5040.00,
      "totalNonRoomRevenue": 1260.00,
      "roomRevenue": 5040.00,
      "roomRevenueTax": 504.00,
      "roomRevenueCommission": 252.00,
      "roomRevenueServiceCharge": 126.00,
      "nonRoomRevenue": 1260.00,
      "nonRoomRevenueTax": 126.00,
      "nonRoomRevenueCommission": 63.00,
      "nonRoomRevenueServiceCharge": 31.50
    }
  ]
}
```

## SOAP API Examples

### Example 1: Hotel Reservation Notification

```xml
<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Header>
    <wsse:Security soap:mustUnderstand="1"
      xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
      <wsse:UsernameToken>
        <wsse:Username>CHAIN123</wsse:Username>
        <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">
          HOTEL123
        </wsse:Password>
      </wsse:UsernameToken>
    </wsse:Security>
  </soap:Header>
  <soap:Body>
    <OTA_HotelResNotifRQ
      xmlns="http://www.opentravel.org/OTA/2003/05"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_HotelResNotifRQ.xsd"
      Version="1.0">

      <POS>
        <Source>
          <RequestorID ID="PMS_DEMO" Type="PMS"/>
        </Source>
      </POS>

      <HotelReservations>
        <HotelReservation RoomStayReservation="true">
          <UniqueID ID="RES-2024-001" Type="Reservation"/>

          <RoomStays>
            <RoomStay RoomStayStatus="Confirmed">
              <RoomTypes>
                <RoomType RoomTypeCode="DELUXE" NumberOfUnits="1"/>
              </RoomTypes>

              <RatePlans>
                <RatePlan RatePlanCode="BAR"/>
              </RatePlans>

              <GuestCounts>
                <GuestCount AgeQualifyingCode="10" Count="2"/>
              </GuestCounts>

              <TimeSpan Start="2024-02-01" End="2024-02-03"/>

              <Total>
                <AmountAfterTax Amount="470.00" CurrencyCode="USD"/>
              </Total>

              <BasicPropertyInfo HotelCode="HOTEL123"/>

              <ResGuestRPHs>
                <ResGuestRPH RPH="1"/>
              </ResGuestRPHs>

              <GuestRoom>
                <IndexNumber>1</IndexNumber>
                <RoomReference RoomReference="ROOM-001"/>
              </GuestRoom>
            </RoomStay>
          </RoomStays>

          <ResGuests>
            <ResGuest ResGuestRPH="1">
              <Profiles>
                <ProfileInfo>
                  <Profile>
                    <Customer>
                      <PersonName>
                        <GivenName>John</GivenName>
                        <Surname>Smith</Surname>
                      </PersonName>
                      <Telephone PhoneTechType="Phone" CountryAccessCode="1" AreaCode="555" PhoneNumber="0123"/>
                      <Email>john.smith@example.com</Email>
                      <Address>
                        <StreetNmbr>123</StreetNmbr>
                        <StreetName>Main St</StreetName>
                        <CityName>New York</CityName>
                        <PostalCode>10001</PostalCode>
                        <CountryName Code="USA"/>
                      </Address>
                    </Customer>
                  </Profile>
                </ProfileInfo>
              </Profiles>
            </ResGuest>
          </ResGuests>

          <ResGlobalInfo>
            <HotelReference HotelCode="HOTEL123" ChainCode="CHAIN123"/>
            <TimeSpan Start="2024-01-15T10:30:00"/>
            <Total>
              <AmountAfterTax Amount="470.00" CurrencyCode="USD"/>
            </Total>
            <Comment>
              <Text>Late arrival expected</Text>
            </Comment>
          </ResGlobalInfo>
        </HotelReservation>
      </HotelReservations>
    </OTA_HotelResNotifRQ>
  </soap:Body>
</soap:Envelope>
```

### Example 2: Hotel Statistics Notification

```xml
<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Header>
    <wsse:Security soap:mustUnderstand="1"
      xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
      <wsse:UsernameToken>
        <wsse:Username>CHAIN123</wsse:Username>
        <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">
          HOTEL123
        </wsse:Password>
      </wsse:UsernameToken>
    </wsse:Security>
  </soap:Header>
  <soap:Body>
    <OTA_HotelStatsNotifRQ
      xmlns="http://www.opentravel.org/OTA/2003/05"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_HotelStatsNotifRQ.xsd"
      Version="1.0">

      <POS>
        <Source>
          <RequestorID ID="PMS_DEMO" Type="PMS"/>
        </Source>
      </POS>

      <Statistics>
        <Statistic ReportDate="2024-01-15">
          <HotelReference HotelCode="HOTEL123" ChainCode="CHAIN123"/>

          <StatisticItems>
            <StatisticItem>
              <StatisticCode Code="11" CodeContext="ROOM_SOLD"/>
              <StatisticValue>25</StatisticValue>
              <RoomTypeCode>DELUXE</RoomTypeCode>
              <RatePlanCode>BAR</RatePlanCode>
              <MarketSegmentCode>LEISURE</MarketSegmentCode>
              <BookingSourceCode>WEBSITE</BookingSourceCode>
            </StatisticItem>

            <StatisticItem>
              <StatisticCode Code="9" CodeContext="REVENUE"/>
              <StatisticValue CurrencyCode="USD">3000.00</StatisticValue>
              <RoomTypeCode>DELUXE</RoomTypeCode>
              <RatePlanCode>BAR</RatePlanCode>
              <MarketSegmentCode>LEISURE</MarketSegmentCode>
              <BookingSourceCode>WEBSITE</BookingSourceCode>
            </StatisticItem>

            <StatisticItem>
              <StatisticCode Code="14" CodeContext="CANCELLATION"/>
              <StatisticValue>2</StatisticValue>
              <RoomTypeCode>DELUXE</RoomTypeCode>
              <RatePlanCode>BAR</RatePlanCode>
              <MarketSegmentCode>LEISURE</MarketSegmentCode>
              <BookingSourceCode>WEBSITE</BookingSourceCode>
            </StatisticItem>

            <StatisticItem>
              <StatisticCode Code="10" CodeContext="NO_OF_BOOKINGS"/>
              <StatisticValue>15</StatisticValue>
              <RoomTypeCode>DELUXE</RoomTypeCode>
              <RatePlanCode>BAR</RatePlanCode>
              <MarketSegmentCode>LEISURE</MarketSegmentCode>
              <BookingSourceCode>WEBSITE</BookingSourceCode>
            </StatisticItem>
          </StatisticItems>
        </Statistic>
      </Statistics>
    </OTA_HotelStatsNotifRQ>
  </soap:Body>
</soap:Envelope>
```

## Error Response Examples

### Example 1: Validation Error
**Request**: Missing required fields

```json
{
  "hotelCode": "HOTEL123",
  "reference": "RES-2024-001",
  "bookingDate": "2024-01-15T10:30:00Z",
  "additionalNote": "",
  "lastUpdate": "2024-01-15T14:30:00Z",
  "bookingSourceCode": "WEBSITE",
  "marketSegmentCode": "LEISURE",
  "isHotelCollect": true,
  "reservationRooms": [
    {
      "roomReference": "ROOM-001",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "BAR",
      "status": "confirm",
      "arrival": "2024-02-01T15:00:00Z",
      "departure": "2024-02-03T11:00:00Z",
      "adult": 2,
      "child": 0,
      "isComplimentary": false,
      "isHouseUse": false,
      "guests": [],
      "rates": []
    }
  ]
}
```

**Response**:
```json
{
  "success": "ERROR",
  "message": "Validation failed",
  "details": [
    {
      "field": "additionalNote",
      "message": "additionalNote should not be empty",
      "code": "IS_EMPTY"
    },
    {
      "field": "reservationRooms[0].guests",
      "message": "At least one guest must be provided",
      "code": "ARRAY_MIN_SIZE"
    },
    {
      "field": "reservationRooms[0].rates",
      "message": "At least one rate must be set",
      "code": "ARRAY_MIN_SIZE"
    }
  ]
}
```

### Example 2: Business Logic Error
**Request**: Arrival after departure

```json
{
  "hotelCode": "HOTEL123",
  "reference": "RES-2024-001",
  "bookingDate": "2024-01-15T10:30:00Z",
  "additionalNote": "Test booking",
  "lastUpdate": "2024-01-15T14:30:00Z",
  "bookingSourceCode": "WEBSITE",
  "marketSegmentCode": "LEISURE",
  "isHotelCollect": true,
  "reservationRooms": [
    {
      "roomReference": "ROOM-001",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "BAR",
      "status": "confirm",
      "arrival": "2024-02-03T15:00:00Z",
      "departure": "2024-02-01T11:00:00Z",
      "adult": 2,
      "child": 0,
      "isComplimentary": false,
      "isHouseUse": false,
      "guests": [
        {
          "firstName": "John",
          "lastName": "Smith",
          "birthDate": "1985-05-15T00:00:00Z",
          "gender": "male",
          "address": "123 Main Street",
          "city": "New York",
          "zipCode": "10001",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0123",
          "email": "john.smith@example.com",
          "isMainGuest": true
        }
      ],
      "rates": [
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-02-01T00:00:00Z",
          "chargingDateTo": "2024-02-01T00:00:00Z",
          "isRoomRevenue": true,
          "price": 200.00,
          "tax": 20.00,
          "serviceCharge": 15.00,
          "commission": 0.00,
          "currency": "USD"
        }
      ]
    }
  ]
}
```

**Response**:
```json
{
  "success": "ERROR",
  "message": "Business logic validation failed",
  "details": "Arrival date must be before departure date"
}
```

### Example 3: Hotel Not Found Error

**Request**: Invalid hotel code

```json
{
  "hotelCode": "INVALID_HOTEL",
  "reference": "RES-2024-001",
  "bookingDate": "2024-01-15T10:30:00Z",
  "additionalNote": "Test booking",
  "lastUpdate": "2024-01-15T14:30:00Z",
  "bookingSourceCode": "WEBSITE",
  "marketSegmentCode": "LEISURE",
  "isHotelCollect": true,
  "reservationRooms": [
    {
      "roomReference": "ROOM-001",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "BAR",
      "status": "confirm",
      "arrival": "2024-02-01T15:00:00Z",
      "departure": "2024-02-03T11:00:00Z",
      "adult": 2,
      "child": 0,
      "isComplimentary": false,
      "isHouseUse": false,
      "guests": [
        {
          "firstName": "John",
          "lastName": "Smith",
          "birthDate": "1985-05-15T00:00:00Z",
          "gender": "male",
          "address": "123 Main Street",
          "city": "New York",
          "zipCode": "10001",
          "country": "USA",
          "nationality": "USA",
          "phoneNumber": "+1-555-0123",
          "email": "john.smith@example.com",
          "isMainGuest": true
        }
      ],
      "rates": [
        {
          "packageCode": "RR",
          "packageName": "Room Revenue",
          "chargingDateFrom": "2024-02-01T00:00:00Z",
          "chargingDateTo": "2024-02-01T00:00:00Z",
          "isRoomRevenue": true,
          "price": 200.00,
          "tax": 20.00,
          "serviceCharge": 15.00,
          "commission": 0.00,
          "currency": "USD"
        }
      ]
    }
  ]
}
```

**Response**:
```json
{
  "success": "ERROR",
  "message": "Hotel not found",
  "details": "Hotel with code 'INVALID_HOTEL' does not exist in the system"
}
```

## Integration Examples

### Example 1: Batch Processing
**Scenario**: Process multiple reservations from overnight batch

```javascript
const reservations = [
  // Reservation 1
  {
    "hotelCode": "HOTEL123",
    "reference": "BATCH-001",
    // ... rest of reservation data
  },
  // Reservation 2
  {
    "hotelCode": "HOTEL123",
    "reference": "BATCH-002",
    // ... rest of reservation data
  },
  // Reservation 3
  {
    "hotelCode": "HOTEL123",
    "reference": "BATCH-003",
    // ... rest of reservation data
  }
];

// Process reservations with error handling
async function processBatchReservations(reservations) {
  const results = [];

  for (const reservation of reservations) {
    try {
      const response = await fetch('/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reservation)
      });

      const result = await response.json();
      results.push({
        reference: reservation.reference,
        success: true,
        response: result
      });

    } catch (error) {
      results.push({
        reference: reservation.reference,
        success: false,
        error: error.message
      });

      // Log error for manual review
      console.error(`Failed to process reservation ${reservation.reference}:`, error);
    }

    // Add small delay to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  return results;
}

// Execute batch processing
processBatchReservations(reservations)
  .then(results => {
    console.log('Batch processing completed:', results);
    // Generate summary report
    const successful = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;
    console.log(`Success: ${successful}, Failed: ${failed}`);
  });
```

### Example 2: Retry Logic with Exponential Backoff

```javascript
async function sendRequestWithRetry(url, data, maxRetries = 3) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      });

      if (response.ok) {
        return await response.json();
      }

      // If response status is 4xx (client error), don't retry
      if (response.status >= 400 && response.status < 500) {
        const error = await response.json();
        throw new Error(`Client error: ${error.message}`);
      }

      // For 5xx errors, retry with exponential backoff
      throw new Error(`Server error: ${response.status}`);

    } catch (error) {
      console.log(`Attempt ${attempt} failed:`, error.message);

      if (attempt === maxRetries) {
        throw error; // Re-throw after final attempt
      }

      // Exponential backoff: wait 1s, 2s, 4s
      const delayMs = Math.pow(2, attempt - 1) * 1000;
      console.log(`Retrying in ${delayMs}ms...`);
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
}

// Usage
sendRequestWithRetry('/bookings', reservationData)
  .then(result => console.log('Success:', result))
  .catch(error => console.error('All retries failed:', error));
```

### Example 3: Data Validation Before API Call

```javascript
function validateReservation(reservation) {
  const errors = [];

  // Validate required fields
  if (!reservation.hotelCode) {
    errors.push('Hotel code is required');
  }

  if (!reservation.reference) {
    errors.push('Reservation reference is required');
  }

  if (!reservation.reservationRooms || reservation.reservationRooms.length === 0) {
    errors.push('At least one room reservation is required');
  }

  // Validate each room reservation
  reservation.reservationRooms?.forEach((room, index) => {
    if (!room.arrival || !room.departure) {
      errors.push(`Room ${index + 1}: Arrival and departure dates are required`);
    }

    if (new Date(room.arrival) >= new Date(room.departure)) {
      errors.push(`Room ${index + 1}: Arrival must be before departure`);
    }

    if (!room.guests || room.guests.length === 0) {
      errors.push(`Room ${index + 1}: At least one guest is required`);
    }

    // Validate main guest
    const mainGuests = room.guests?.filter(g => g.isMainGuest) || [];
    if (mainGuests.length !== 1) {
      errors.push(`Room ${index + 1}: Exactly one main guest must be specified`);
    }

    // Validate rates
    if (!room.rates || room.rates.length === 0) {
      errors.push(`Room ${index + 1}: At least one rate is required`);
    }
  });

  return errors;
}

// Usage
const validationErrors = validateReservation(reservationData);
if (validationErrors.length > 0) {
  console.error('Validation errors:', validationErrors);
  // Handle validation errors
} else {
  // Send to API
  sendRequestWithRetry('/bookings', reservationData);
}
```

These examples provide comprehensive coverage of typical API usage scenarios, error handling, and integration patterns. They can be used as templates for implementing the Radiant1 PMS API in your PMS system.