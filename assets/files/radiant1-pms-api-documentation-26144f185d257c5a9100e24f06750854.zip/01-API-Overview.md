# Radiant1 PMS API Overview

## Introduction

The Radiant1 PMS API provides standardized interfaces for Property Management Systems (PMS) to integrate with the Radiant1 platform. This API supports both REST and SOAP protocols to ensure compatibility with various PMS implementations.

## API Protocols

### REST APIs (OpenAPI)
- **Push Reservation**: POST /bookings
- **Push Statistics**: POST /statistics
- **Health Check**: GET /health-checker

### SOAP APIs (OTA Standards)
- **SOAP Booking**: POST /soap/request (OTA_HotelResNotifRQ)
- **SOAP Statistic**: POST /soap/request (OTA_HotelStatsNotifRQ)
- **SOAP Ping**: POST /soap/request (OTA_PingRQ)

## Base URLs

### Development Environment
```
REST API: https://dev-api.radiant1.com
SOAP API: https://dev-api.radiant1.com/soap
```

### Production Environment
```
REST API: https://api.radiant1.com
SOAP API: https://api.radiant1.com/soap
```

## Authentication

### REST APIs
- Currently uses hotel code validation
- Future versions will implement API key authentication

### SOAP APIs
- Uses SOAP Auth Guard with hotel credentials
- Requires valid ChainCode and HotelCode in requests

## Request Headers

### REST APIs
```json
{
  "Content-Type": "application/json",
  "Accept": "application/json",
  "User-Agent": "Your-PMS-Name/Version"
}
```

### SOAP APIs
```xml
<soap:Header>
  <wsse:Security>
    <!-- Authentication credentials -->
  </wsse:Security>
</soap:Header>
```

## Date Format Requirements

All date fields must use **ISO 8601** format:
- **Date**: `YYYY-MM-DD` (e.g., "2024-01-15")
- **DateTime**: `YYYY-MM-DDTHH:mm:ssZ` (e.g., "2024-01-15T14:30:00Z")

## Response Format

### Success Response
```json
{
  "success": "SUCCESS",
  "message": "Operation completed successfully"
}
```

### Error Response
```json
{
  "success": "ERROR",
  "message": "Error description",
  "details": "Additional error information"
}
```

## HTTP Status Codes

| Status Code | Description |
|-------------|-------------|
| 200 | Request processed successfully |
| 400 | Bad Request - Validation failed |
| 401 | Unauthorized - Authentication failed |
| 404 | Not Found - Resource not found |
| 422 | Unprocessable Entity - Business logic validation failed |
| 500 | Internal Server Error |

## Rate Limiting

- **REST APIs**: 100 requests per minute per hotel
- **SOAP APIs**: 50 requests per minute per hotel

## Support

For technical support and API integration assistance:
- **Email**: api-support@radiant1.com
- **Documentation**: https://docs.radiant1.com
- **Status Page**: https://status.radiant1.com

## SDKs and Libraries

Official SDKs are available for:
- **Node.js**: `@radiant1/pms-sdk`
- **Python**: `radiant1-pms-sdk`
- **Java**: `com.radiant1:pms-sdk`
- **C#**: `Radiant1.PMS.SDK`

## Changelog

### v2.1.0 (Latest)
- Enhanced statistics data structure
- Added additional guest information fields
- Improved validation error messages

### v2.0.0
- Introduced REST API endpoints
- Enhanced SOAP authentication
- Added comprehensive validation rules

### v1.0.0
- Initial SOAP API release