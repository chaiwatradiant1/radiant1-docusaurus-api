# SOAP API

## Overview

The Radiant1 SOAP API implements OTA (Open Travel Alliance) standards for hotel reservation and statistics synchronization. This interface is designed for PMS systems that prefer SOAP-based integration using industry-standard XML messages.

## Endpoint

```
POST /soap/request
```

## SOAP Actions

| SOAP Action | Description | OTA Standard |
|-------------|-------------|--------------|
| `OTA_HotelResNotifRQ` | Hotel Reservation Notification | OTA 2007B |
| `OTA_HotelStatsNotifRQ` | Hotel Statistics Notification | Custom Extension |
| `OTA_PingRQ` | Ping/Health Check | OTA 2006A |
| `OTA_HotelInvCountNotifRQ` | Inventory Count Notification | OTA 2007B |

## Authentication

### WS-Security Header
```xml
<soap:Header>
  <wsse:Security soap:mustUnderstand="1"
    xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
    <wsse:UsernameToken>
      <wsse:Username>YOUR_CHAIN_CODE</wsse:Username>
      <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">
        YOUR_HOTEL_CODE
      </wsse:Password>
    </wsse:UsernameToken>
  </wsse:Security>
</soap:Header>
```

## SOAP Envelope Structure

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Header>
    <!-- WS-Security authentication -->
  </soap:Header>
  <soap:Body>
    <!-- OTA Request payload -->
  </soap:Body>
</soap:Envelope>
```

## 1. Hotel Reservation Notification (OTA_HotelResNotifRQ)

### Request Structure

```xml
<OTA_HotelResNotifRQ
  xmlns="http://www.opentravel.org/OTA/2003/05"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_HotelResNotifRQ.xsd"
  Version="1.0">

  <POS>
    <Source>
      <RequestorID ID="YOUR_PMS_ID" Type="PMS"/>
    </Source>
  </POS>

  <HotelReservations>
    <HotelReservation RoomStayReservation="true">
      <UniqueID ID="RES-2024-001" Type="Reservation"/>

      <RoomStays>
        <RoomStay RoomStayStatus="Confirmed">
          <RoomTypes>
            <RoomType RoomTypeCode="DELUXE" NumberOfUnits="1"/>
          </RoomTypes>

          <RatePlans>
            <RatePlan RatePlanCode="BAR"/>
          </RatePlans>

          <GuestCounts>
            <GuestCount AgeQualifyingCode="10" Count="2"/> <!-- Adults -->
            <GuestCount AgeQualifyingCode="8" Count="1"/>  <!-- Children -->
          </GuestCounts>

          <TimeSpan Start="2024-02-01" End="2024-02-03"/>

          <Total>
            <AmountAfterTax Amount="350.00" CurrencyCode="USD"/>
          </Total>

          <BasicPropertyInfo HotelCode="HOTEL123"/>

          <ResGuestRPHs>
            <ResGuestRPH RPH="1"/>
          </ResGuestRPHs>

          <GuestRoom>
            <IndexNumber>1</IndexNumber>
            <RoomReference RoomReference="ROOM-001"/>
          </GuestRoom>
        </RoomStay>
      </RoomStays>

      <ResGuests>
        <ResGuest ResGuestRPH="1">
          <Profiles>
            <ProfileInfo>
              <Profile>
                <Customer>
                  <PersonName>
                    <NamePrefix>Mr.</NamePrefix>
                    <GivenName>John</GivenName>
                    <Surname>Doe</Surname>
                  </PersonName>
                  <Telephone PhoneTechType="Phone" CountryAccessCode="1" AreaCode="555" PhoneNumber="0123"/>
                  <Email>john.doe@example.com</Email>
                  <Address>
                    <StreetNmbr>123</StreetNmbr>
                    <StreetName>Main St</StreetName>
                    <CityName>New York</CityName>
                    <PostalCode>10001</PostalCode>
                    <CountryName Code="USA"/>
                  </Address>
                </Customer>
              </Profile>
            </ProfileInfo>
          </Profiles>
        </ResGuest>
      </ResGuests>

      <ResGlobalInfo>
        <HotelReference HotelCode="HOTEL123" ChainCode="CHAIN123"/>

        <TimeSpan Start="2024-01-15T10:30:00"/>

        <Total>
          <AmountAfterTax Amount="350.00" CurrencyCode="USD"/>
        </Total>

        <Guarantee>
          <GuaranteesAccepted>
            <GuaranteeAccepted>
              <PaymentCard>
                <CardType Code="VI"/>
                <CardNumber>4111111111111111</CardNumber>
                <SeriesCode Code="123"/>
                <CardHolderName>JOHN DOE</CardHolderName>
                <CardExpireDate>2025-12</CardExpireDate>
              </PaymentCard>
            </GuaranteeAccepted>
          </GuaranteesAccepted>
        </Guarantee>

        <Profiles>
          <ProfileInfo>
            <Profile>
              <Customer>
                <CustLoyalty MembershipID="LOYALTY123"/>
              </Customer>
            </Profile>
          </ProfileInfo>
        </Profiles>

        <Comment>
          <Text>Late arrival expected</Text>
        </Comment>
      </ResGlobalInfo>
    </HotelReservation>
  </HotelReservations>
</OTA_HotelResNotifRQ>
```

### Key Fields

#### HotelReference
- **HotelCode**: Your hotel identifier
- **ChainCode**: Your chain/brand identifier

#### RoomStay Information
- **RoomTypeCode**: Room type identifier
- **RatePlanCode**: Rate plan identifier
- **RoomStayStatus**: Reservation status (Confirmed, Tentative, etc.)
- **TimeSpan**: Arrival and departure dates

#### Guest Information
- **AgeQualifyingCode**: 10 (Adult), 8 (Child), 7 (Infant)
- **ResGuestRPH**: Reference to guest profile
- **PersonName**: Guest name details

#### Payment Information
- **Guarantee**: Payment guarantee details
- **PaymentCard**: Credit card information (if applicable)

## 2. Hotel Statistics Notification (OTA_HotelStatsNotifRQ)

### Request Structure

```xml
<OTA_HotelStatsNotifRQ
  xmlns="http://www.opentravel.org/OTA/2003/05"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_HotelStatsNotifRQ.xsd"
  Version="1.0">

  <POS>
    <Source>
      <RequestorID ID="YOUR_PMS_ID" Type="PMS"/>
    </Source>
  </POS>

  <Statistics>
    <Statistic ReportDate="2024-01-15">
      <HotelReference HotelCode="HOTEL123" ChainCode="CHAIN123"/>

      <StatisticItems>
        <!-- Room Sold Statistics -->
        <StatisticItem>
          <StatisticCode Code="11" CodeContext="ROOM_SOLD"/>
          <StatisticValue>25</StatisticValue>
          <RoomTypeCode>DELUXE</RoomTypeCode>
          <RatePlanCode>BAR</RatePlanCode>
          <MarketSegmentCode>LEISURE</MarketSegmentCode>
          <BookingSourceCode>WEBSITE</BookingSourceCode>
        </StatisticItem>

        <!-- Revenue Statistics -->
        <StatisticItem>
          <StatisticCode Code="9" CodeContext="REVENUE"/>
          <StatisticValue CurrencyCode="USD">3000.00</StatisticValue>
          <RoomTypeCode>DELUXE</RoomTypeCode>
          <RatePlanCode>BAR</RatePlanCode>
          <MarketSegmentCode>LEISURE</MarketSegmentCode>
          <BookingSourceCode>WEBSITE</BookingSourceCode>
        </StatisticItem>

        <!-- Cancellation Statistics -->
        <StatisticItem>
          <StatisticCode Code="14" CodeContext="CANCELLATION"/>
          <StatisticValue>2</StatisticValue>
          <RoomTypeCode>DELUXE</RoomTypeCode>
          <RatePlanCode>BAR</RatePlanCode>
          <MarketSegmentCode>LEISURE</MarketSegmentCode>
          <BookingSourceCode>WEBSITE</BookingSourceCode>
        </StatisticItem>

        <!-- Number of Bookings -->
        <StatisticItem>
          <StatisticCode Code="10" CodeContext="NO_OF_BOOKINGS"/>
          <StatisticValue>15</StatisticValue>
          <RoomTypeCode>DELUXE</RoomTypeCode>
          <RatePlanCode>BAR</RatePlanCode>
          <MarketSegmentCode>LEISURE</MarketSegmentCode>
          <BookingSourceCode>WEBSITE</BookingSourceCode>
        </StatisticItem>
      </StatisticItems>
    </Statistic>
  </Statistics>
</OTA_HotelStatsNotifRQ>
```

### Statistic Code Context Values

| Code | Context | Description |
|------|---------|-------------|
| 9 | REVENUE | Total revenue amount |
| 11 | ROOM_SOLD | Number of rooms sold |
| 14 | CANCELLATION | Number of cancellations |
| 10 | NO_OF_BOOKINGS | Number of bookings |

## 3. Ping Request (OTA_PingRQ)

### Request Structure

```xml
<OTA_PingRQ
  xmlns="http://www.opentravel.org/OTA/2003/05"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_PingRQ.xsd"
  Version="1.0">

  <EchoData>This is a test message</EchoData>
</OTA_PingRQ>
```

### Response Structure

```xml
<OTA_PingRS
  xmlns="http://www.opentravel.org/OTA/2003/05"
  Version="1.0">

  <Success/>
  <EchoData>This is a test message</EchoData>
</OTA_PingRS>
```

## Response Structure

### Success Response

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <OTA_HotelResNotifRS
      xmlns="http://www.opentravel.org/OTA/2003/05"
      Version="1.0">
      <Success/>
    </OTA_HotelResNotifRS>
  </soap:Body>
</soap:Envelope>
```

### Error Response

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <OTA_HotelResNotifRS
      xmlns="http://www.opentravel.org/OTA/2003/05"
      Version="1.0">
      <Errors>
        <Error Type="3" Code="450" ShortText="Validation failed">
          <Text>Hotel not found</Text>
        </Error>
      </Errors>
    </OTA_HotelResNotifRS>
  </soap:Body>
</soap:Envelope>
```

### Error Codes

| Code | Type | Description |
|------|------|-------------|
| 450 | 3 | Authentication/Authorization error |
| 451 | 3 | Hotel not found |
| 452 | 3 | Invalid XML format |
| 453 | 3 | Business logic validation failed |
| 454 | 3 | Required fields missing |

## Common Error Scenarios

### Authentication Failed
```xml
<soap:Fault>
  <faultcode>soap:Client</faultcode>
  <faultstring>Authentication failed</faultstring>
  <detail>
    <Error>Invalid credentials provided</Error>
  </detail>
</soap:Fault>
```

### Validation Error
```xml
<OTA_HotelResNotifRS Version="1.0">
  <Errors>
    <Error Type="3" Code="452" ShortText="XML Validation Error">
      <Text>Invalid date format in TimeSpan element</Text>
    </Error>
  </Errors>
</OTA_HotelResNotifRS>
```

## Best Practices

### 1. XML Validation
- Validate XML against OTA schemas before sending
- Use proper XML namespaces
- Ensure all required elements are present

### 2. Error Handling
- Implement robust error handling for SOAP faults
- Log detailed error information for troubleshooting
- Implement retry logic for transient errors

### 3. Performance
- Use HTTP Keep-Alive for multiple requests
- Compress large XML payloads
- Batch multiple reservations when possible

### 4. Security
- Use HTTPS for all SOAP communications
- Implement proper authentication headers
- Validate incoming SOAP messages

## Integration Notes

- SOAP requests are processed synchronously
- All requests are logged for audit purposes
- Rate limiting applies (50 requests per minute per hotel)
- Implement exponential backoff for failed requests
- Test against development environment first

## SDK Support

### .NET (C#)
```csharp
var client = new Radiant1SoapClient();
client.ClientCredentials.UserName.UserName = "CHAIN123";
client.ClientCredentials.UserName.Password = "HOTEL123";

var request = new OTA_HotelResNotifRQ { /* ... */ };
var response = await client.OTA_HotelResNotifRQAsync(request);
```

### Java
```java
Radiant1SoapService service = new Radiant1SoapService();
Radiant1Soap port = service.getRadiant1SoapPort();

BindingProvider bp = (BindingProvider) port;
bp.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, "CHAIN123");
bp.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, "HOTEL123");

OTA_HotelResNotifRQ request = new OTA_HotelResNotifRQ();
// ... populate request
OTA_HotelResNotifRS response = port.otaHotelResNotifRQ(request);
```

### PHP
```php
$client = new SoapClient("https://api.radiant1.com/soap?wsdl", [
    'login' => 'CHAIN123',
    'password' => 'HOTEL123',
    'trace' => true
]);

$request = [
    'OTA_HotelResNotifRQ' => [
        // ... request structure
    ]
];

$response = $client->__soapCall('OTA_HotelResNotifRQ', [$request]);
```