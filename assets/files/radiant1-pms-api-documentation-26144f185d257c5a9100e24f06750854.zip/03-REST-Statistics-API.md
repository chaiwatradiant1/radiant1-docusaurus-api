# REST Statistics API

## Push Statistics

### Endpoint
```
POST /statistics
```

### Description
Push daily statistics data from your PMS to the Radiant1 platform. This endpoint receives comprehensive hotel performance metrics including revenue, occupancy, and booking data.

### Request Headers
```json
{
  "Content-Type": "application/json",
  "Accept": "application/json"
}
```

### Request Body

#### StatisticDto
| Field | Type | Required | Description | Example |
|-------|------|----------|-------------|---------|
| `hotelCode` | string | Yes | Unique hotel identifier | "HOTEL123" |
| `data` | array | Yes | Array of statistics data entries | [StatisticDataDto] |

#### StatisticDataDto
| Field | Type | Required | Description | Example |
|-------|------|----------|-------------|---------|
| `date` | string (ISO 8601) | Yes | Statistics date | "2024-01-15" |
| `roomTypeCode` | string | Yes | Room type identifier | "DELUXE" |
| `ratePlanCode` | string | Yes | Rate plan identifier | "BAR" |
| `marketSegmentCode` | string | Yes | Market segment identifier | "LEISURE" |
| `bookingSourceCode` | string | Yes | Booking source identifier | "WEBSITE" |
| `roomSold` | number | Yes | Number of rooms sold | 25 |
| `cancellation` | number | Yes | Number of cancellations | 2 |
| `noOfBookings` | number | Yes | Number of bookings | 15 |
| `totalRevenue` | number | Yes | Total revenue amount | 3750.00 |
| `totalRoomRevenue` | number | Yes | Total room revenue | 3000.00 |
| `totalNonRoomRevenue` | number | Yes | Total non-room revenue | 750.00 |
| `roomRevenue` | number | Yes | Room revenue amount | 3000.00 |
| `roomRevenueTax` | number | Yes | Room revenue tax | 300.00 |
| `roomRevenueCommission` | number | Yes | Room revenue commission | 150.00 |
| `roomRevenueServiceCharge` | number | Yes | Room revenue service charge | 75.00 |
| `nonRoomRevenue` | number | Yes | Non-room revenue amount | 750.00 |
| `nonRoomRevenueTax` | number | Yes | Non-room revenue tax | 75.00 |
| `nonRoomRevenueCommission` | number | Yes | Non-room revenue commission | 37.50 |
| `nonRoomRevenueServiceCharge` | number | Yes | Non-room revenue service charge | 18.75 |

### Field Descriptions

#### Core Metrics
- **roomSold**: Total number of rooms occupied/sold for the date
- **cancellation**: Number of cancelled reservations for the date
- **noOfBookings**: Number of new bookings created for the date

#### Revenue Breakdown
- **totalRevenue**: Gross total revenue (room + non-room revenue)
- **totalRoomRevenue**: Gross room revenue before deductions
- **totalNonRoomRevenue**: Gross non-room revenue before deductions

#### Room Revenue Details
- **roomRevenue**: Net room revenue amount
- **roomRevenueTax**: Tax amount on room revenue
- **roomRevenueCommission**: Commission paid on room revenue
- **roomRevenueServiceCharge**: Service charges on room revenue

#### Non-Room Revenue Details
- **nonRoomRevenue**: Net non-room revenue amount (F&B, spa, etc.)
- **nonRoomRevenueTax**: Tax amount on non-room revenue
- **nonRoomRevenueCommission**: Commission paid on non-room revenue
- **nonRoomRevenueServiceCharge**: Service charges on non-room revenue

### Request Example

```json
{
  "hotelCode": "HOTEL123",
  "data": [
    {
      "date": "2024-01-15",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "BAR",
      "marketSegmentCode": "LEISURE",
      "bookingSourceCode": "WEBSITE",
      "roomSold": 25,
      "cancellation": 2,
      "noOfBookings": 15,
      "totalRevenue": 3750.00,
      "totalRoomRevenue": 3000.00,
      "totalNonRoomRevenue": 750.00,
      "roomRevenue": 3000.00,
      "roomRevenueTax": 300.00,
      "roomRevenueCommission": 150.00,
      "roomRevenueServiceCharge": 75.00,
      "nonRoomRevenue": 750.00,
      "nonRoomRevenueTax": 75.00,
      "nonRoomRevenueCommission": 37.50,
      "nonRoomRevenueServiceCharge": 18.75
    },
    {
      "date": "2024-01-15",
      "roomTypeCode": "STANDARD",
      "ratePlanCode": "BAR",
      "marketSegmentCode": "BUSINESS",
      "bookingSourceCode": "OTA",
      "roomSold": 40,
      "cancellation": 3,
      "noOfBookings": 20,
      "totalRevenue": 4800.00,
      "totalRoomRevenue": 4000.00,
      "totalNonRoomRevenue": 800.00,
      "roomRevenue": 4000.00,
      "roomRevenueTax": 400.00,
      "roomRevenueCommission": 200.00,
      "roomRevenueServiceCharge": 100.00,
      "nonRoomRevenue": 800.00,
      "nonRoomRevenueTax": 80.00,
      "nonRoomRevenueCommission": 40.00,
      "nonRoomRevenueServiceCharge": 20.00
    }
  ]
}
```

### Response

#### Success Response (200 OK)
```json
{
  "message": "Statistics processed successfully"
}
```

#### Error Response (400 Bad Request)
```json
{
  "success": "ERROR",
  "message": "Validation failed",
  "details": [
    {
      "field": "data[0].date",
      "message": "Date must be in YYYY-MM-DD format"
    }
  ]
}
```

#### Error Response (404 Not Found)
```json
{
  "success": "ERROR",
  "message": "Hotel not found",
  "details": "Hotel code 'INVALID123' does not exist"
}
```

### Data Aggregation Examples

#### Daily Summary by Room Type
```json
{
  "hotelCode": "HOTEL123",
  "data": [
    {
      "date": "2024-01-15",
      "roomTypeCode": "DELUXE",
      "ratePlanCode": "ALL",
      "marketSegmentCode": "ALL",
      "bookingSourceCode": "ALL",
      "roomSold": 25,
      "cancellation": 2,
      "noOfBookings": 15,
      "totalRevenue": 3750.00,
      "totalRoomRevenue": 3000.00,
      "totalNonRoomRevenue": 750.00,
      "roomRevenue": 3000.00,
      "roomRevenueTax": 300.00,
      "roomRevenueCommission": 150.00,
      "roomRevenueServiceCharge": 75.00,
      "nonRoomRevenue": 750.00,
      "nonRoomRevenueTax": 75.00,
      "nonRoomRevenueCommission": 37.50,
      "nonRoomRevenueServiceCharge": 18.75
    }
  ]
}
```

#### Daily Summary by Market Segment
```json
{
  "hotelCode": "HOTEL123",
  "data": [
    {
      "date": "2024-01-15",
      "roomTypeCode": "ALL",
      "ratePlanCode": "ALL",
      "marketSegmentCode": "LEISURE",
      "bookingSourceCode": "ALL",
      "roomSold": 35,
      "cancellation": 3,
      "noOfBookings": 18,
      "totalRevenue": 5250.00,
      "totalRoomRevenue": 4200.00,
      "totalNonRoomRevenue": 1050.00,
      "roomRevenue": 4200.00,
      "roomRevenueTax": 420.00,
      "roomRevenueCommission": 210.00,
      "roomRevenueServiceCharge": 105.00,
      "nonRoomRevenue": 1050.00,
      "nonRoomRevenueTax": 105.00,
      "nonRoomRevenueCommission": 52.50,
      "nonRoomRevenueServiceCharge": 26.25
    }
  ]
}
```

### Common Error Scenarios

| Error Code | Description | Solution |
|------------|-------------|----------|
| VALIDATION_FAILED | Required fields missing or invalid format | Check request format and required fields |
| INVALID_DATE_FORMAT | Date not in YYYY-MM-DD format | Use correct date format |
| INVALID_REVENUE_VALUES | Negative revenue values | Ensure all monetary values are positive |
| HOTEL_NOT_FOUND | Hotel code not found | Verify hotel code is correct |
| DUPLICATE_ENTRIES | Duplicate data entries for same date/segment | Ensure unique combinations of date and codes |

### Data Validation Rules

1. **Date Format**: Must be in `YYYY-MM-DD` format
2. **Numeric Values**: All revenue and count fields must be non-negative
3. **Code Values**: Room type, rate plan, market segment, and booking source codes must be valid
4. **Logical Consistency**:
   - totalRevenue should equal totalRoomRevenue + totalNonRoomRevenue
   - roomSold should be reasonable for the hotel's capacity
   - cancellation should not exceed roomSold

### Best Practices

1. **Daily Push**: Send statistics data once per day after business hours
2. **Complete Data**: Include all required fields for accurate reporting
3. **Validation**: Validate data locally before sending to API
4. **Retry Logic**: Implement exponential backoff for failed requests
5. **Timestamp**: Use local hotel date for statistics (not UTC)
6. **Aggregation Level**: Send data at the most granular level available
7. **Audit Trail**: Keep local logs of submitted statistics for reconciliation

### Integration Notes

- Statistics are processed asynchronously
- Data is stored for historical analysis and reporting
- Multiple entries for the same date with different segmentations are allowed
- The API validates hotel configuration before processing
- Failed statistics submissions are logged for troubleshooting

### Performance Considerations

- **Batch Size**: Limit to 100 data entries per request
- **Frequency**: Maximum once per hour per hotel
- **Timeout**: Requests timeout after 30 seconds
- **Retry**: Implement retry logic for failed requests