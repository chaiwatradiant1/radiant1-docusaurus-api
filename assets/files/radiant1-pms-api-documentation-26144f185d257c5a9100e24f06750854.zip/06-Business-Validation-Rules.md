# Business Validation Rules

## Overview

The Radiant1 PMS API implements comprehensive business validation rules to ensure data integrity and compliance with hotel industry standards. These validations are enforced at multiple levels - field validation, business logic validation, and cross-entity validation.

## Validation Hierarchy

### 1. Field-Level Validation
- **Data type validation**: Ensures correct data types and formats
- **Required field validation**: Ensures all mandatory fields are present
- **Format validation**: Validates specific formats (dates, emails, phone numbers)

### 2. Business Logic Validation
- **Relationship validation**: Ensures logical relationships between fields
- **Business rule validation**: Enforces industry-standard business rules
- **Temporal validation**: Validates date/time relationships

### 3. Cross-Entity Validation
- **Consistency validation**: Ensures data consistency across related entities
- **Integrity validation**: Validates referential integrity
- **Aggregate validation**: Validates summary calculations

## Booking Validation Rules

### Reservation Status Rules

#### Room Status Validation
**Rule**: Room status must be 'New' or 'Confirmed' for new reservations
```json
{
  "status": "confirm" // ✅ Valid
}
```
```json
{
  "status": "check_in" // ❌ Invalid for new reservations
}
```
**Exception**: Reservations from ingest systems may bypass this validation (`isIngest: true`)

#### Modification Restrictions
**Rule**: Cannot modify reservations after check-out
- **Condition**: Any room status = 'check_out'
- **Condition**: Current date > departure date
- **Error**: "Cannot modify reservation after Check-Out status"

#### Status Transition Rules
**Valid Transitions**:
- `reserve` → `confirm`
- `confirm` → `check_in`
- `check_in` → `check_out`
- `reserve`/`confirm` → `cancelled`
- `confirm` → `no_show`

**Invalid Transitions**:
- `check_out` → Any other status
- `cancelled` → `confirm` (without special reinstatement process)
- `no_show` → `check_in`

### Guest Validation Rules

#### Main Guest Requirements
**Rule**: Exactly one main guest must be set per room
```json
{
  "guests": [
    {"isMainGuest": true, "firstName": "John"},  // ✅ Valid
    {"isMainGuest": false, "firstName": "Jane"}  // ✅ Valid
  ]
}
```
```json
{
  "guests": [
    {"isMainGuest": true, "firstName": "John"},
    {"isMainGuest": true, "firstName": "Jane"}   // ❌ Invalid - multiple main guests
  ]
}
```

#### Birth Date Validation
**Rule**: Birth date cannot be in the future
```json
{
  "birthDate": "1985-05-15T00:00:00Z" // ✅ Valid
}
```
```json
{
  "birthDate": "2025-05-15T00:00:00Z" // ❌ Invalid - future date
}
```

#### Guest Contact Information
**Rule**: Email and phone number must be valid formats
- **Email**: Must match RFC 5322 standard
- **Phone**: Recommended E.164 format (+1-555-0123)

### Room and Rate Validation Rules

#### Complementary and House Use
**Rule**: `isComplementary` and `isHouseUse` cannot both be true
```json
{
  "isComplementary": true,
  "isHouseUse": false  // ✅ Valid
}
```
```json
{
  "isComplementary": true,
  "isHouseUse": true   // ❌ Invalid - both flags true
}
```

#### Date Relationship Validation
**Rule**: Arrival date must be before departure date
```json
{
  "arrival": "2024-02-01T15:00:00Z",
  "departure": "2024-02-03T11:00:00Z"  // ✅ Valid
}
```
```json
{
  "arrival": "2024-02-03T15:00:00Z",
  "departure": "2024-02-01T11:00:00Z"  // ❌ Invalid - arrival after departure
}
```

#### Stay Dates and Rate Coverage
**Rule**: Rates must cover entire stay period

**Day Use Validation**:
- Arrival and departure on same date
- Exactly one `isRoomRevenue = true` rate required

**Multi-Day Stay Validation**:
- At least one `isRoomRevenue = true` rate per night
- Charging dates must be within stay period
- No gaps in rate coverage

```json
{
  "arrival": "2024-02-01T00:00:00Z",
  "departure": "2024-02-03T00:00:00Z",
  "rates": [
    {"chargingDate": "2024-02-01", "isRoomRevenue": true},  // ✅ Covers night 1
    {"chargingDate": "2024-02-02", "isRoomRevenue": true}   // ✅ Covers night 2
  ]
}
```

#### Package Code Uniqueness
**Rule**: Package codes must not duplicate on the same charging date
```json
{
  "rates": [
    {"packageCode": "RR", "chargingDate": "2024-02-01"},  // ✅ Valid
    {"packageCode": "BF", "chargingDate": "2024-02-01"}   // ✅ Valid - different code
  ]
}
```
```json
{
  "rates": [
    {"packageCode": "RR", "chargingDate": "2024-02-01"},  // ❌ Invalid - duplicate code
    {"packageCode": "RR", "chargingDate": "2024-02-01"}   // on same date
  ]
}
```

### Reservation-Level Validation Rules

#### Room Reference Uniqueness
**Rule**: Room references must be unique within reservation
```json
{
  "reservationRooms": [
    {"roomReference": "ROOM-001"},  // ✅ Valid
    {"roomReference": "ROOM-002"}   // ✅ Valid - different reference
  ]
}
```

#### Booking Date Logic
**Rule**: Booking date cannot be after last update date
```json
{
  "bookingDate": "2024-01-15T10:30:00Z",
  "lastUpdate": "2024-01-15T14:30:00Z"  // ✅ Valid
}
```
```json
{
  "bookingDate": "2024-01-15T16:30:00Z",
  "lastUpdate": "2024-01-15T14:30:00Z"  // ❌ Invalid - booking after update
}
```

#### PMS and Channel Manager ID
**Rule**: PMS ID and Channel Manager ID cannot be set simultaneously
- This applies to internal system fields
- Ensures data source consistency

### Entity Reference Validation

#### Hotel Validation
**Rule**: Hotel must exist and be active
- Validates against hotel master data
- Checks hotel configuration settings

#### Room Type Validation
**Rule**: Room type must exist for the hotel
- Validates room type code exists
- Checks room type is active

#### Rate Plan Validation
**Rule**: Rate plan must exist and be applicable
- Validates rate plan exists
- Checks rate plan is valid for room type
- Skipped for dummy rooms (`isDummy: true`)

#### Market Segment Validation
**Rule**: Market segment must exist for the hotel
- Validates market segment code exists
- Optional field - validation skipped if null

#### Booking Source Validation
**Rule**: Booking source must exist for the hotel
- Validates booking source code exists
- Optional field - validation skipped if null

## Statistics Validation Rules

### Date Format Validation
**Rule**: Statistics date must be in YYYY-MM-DD format
```json
{
  "date": "2024-01-15"  // ✅ Valid
}
```
```json
{
  "date": "2024-01-15T00:00:00Z"  // ❌ Invalid - includes time
}
```

### Revenue Validation Rules
**Rule**: All monetary values must be non-negative
- `totalRevenue` ≥ 0
- `totalRoomRevenue` ≥ 0
- `totalNonRoomRevenue` ≥ 0
- All revenue breakdown fields ≥ 0

### Logical Consistency Validation
**Rule**: Revenue totals should align with breakdown amounts
- `totalRevenue` ≈ `totalRoomRevenue` + `totalNonRoomRevenue`
- Tolerances allowed for rounding differences

### Count Validation Rules
**Rule**: Count fields must be non-negative integers
- `roomSold` ≥ 0
- `cancellation` ≥ 0
- `noOfBookings` ≥ 0

### Code Validation Rules
**Rule**: All reference codes must be valid
- `roomTypeCode` must exist for hotel
- `ratePlanCode` must exist for hotel
- `marketSegmentCode` must exist for hotel
- `bookingSourceCode` must exist for hotel

## SOAP-Specific Validations

### Authentication Validation
**Rule**: Valid credentials required for SOAP requests
- Chain code must be valid
- Hotel code must exist and be active
- Credentials must match hotel configuration

### XML Schema Validation
**Rule**: SOAP requests must validate against OTA schemas
- Correct XML structure
- Valid namespaces
- Required elements present
- Data types match schema definitions

### SOAP Action Validation
**Rule**: SOAP action must be supported
- `OTA_HotelResNotifRQ` - Supported
- `OTA_HotelStatsNotifRQ` - Supported
- `OTA_PingRQ` - Supported
- `OTA_HotelInvCountNotifRQ` - Supported

## Error Handling and Responses

### Validation Error Format
```json
{
  "success": "ERROR",
  "message": "Validation failed",
  "details": [
    {
      "field": "reservationRooms[0].arrival",
      "message": "Arrival date must be before departure date",
      "code": "INVALID_DATE_RELATIONSHIP"
    }
  ]
}
```

### Common Error Codes

| Error Code | HTTP Status | Description |
|------------|-------------|-------------|
| VALIDATION_FAILED | 400 | Request failed field validation |
| BUSINESS_LOGIC_FAILED | 422 | Business rules violated |
| ENTITY_NOT_FOUND | 404 | Referenced entity doesn't exist |
| AUTHENTICATION_FAILED | 401 | Invalid credentials |
| AUTHORIZATION_FAILED | 403 | Insufficient permissions |

### Specific Error Messages

#### Room Status Errors
- "Room status must be New or Confirmed only"
- "Cannot modify reservation after Check-Out status"
- "Cannot modify reservation after Check-Out date"

#### Guest Validation Errors
- "Exactly one main guest must be set"
- "Birthdate cannot be in the future"

#### Rate Validation Errors
- "At least one rate must be set"
- "Some charging date missing from arrival to departure"
- "isRoomRevenue should be at least 1 for each day of stay"
- "Charging date must be within the stay period"
- "Package code must not duplicate in the same charging date"

#### Reference Validation Errors
- "Hotel not found"
- "Room type not found"
- "Rate plan not found"
- "Market segment not found"
- "Booking source not found"

## Best Practices for Integration

### Pre-Validation Checklist
Before sending API requests, validate locally:

1. **Required Fields**: All mandatory fields present
2. **Data Formats**: Dates in ISO 8601, valid email/phone formats
3. **Business Rules**: Date relationships, guest counts, rate coverage
4. **Reference Data**: Verify codes exist in your PMS
5. **Logical Consistency**: Revenue totals, count relationships

### Error Handling Strategy
1. **Retry Logic**: Implement exponential backoff for transient failures
2. **Error Logging**: Log detailed error information for troubleshooting
3. **User Feedback**: Provide clear error messages to end users
4. **Data Recovery**: Implement mechanisms to correct failed data

### Testing Strategy
1. **Positive Testing**: Test valid scenarios
2. **Negative Testing**: Test validation failures
3. **Edge Cases**: Test boundary conditions
4. **Integration Testing**: Test with actual hotel data

### Monitoring and Alerting
1. **Success Rates**: Monitor API success/failure rates
2. **Error Patterns**: Identify common validation failures
3. **Performance**: Monitor response times and throughput
4. **Data Quality**: Monitor data consistency issues

## Custom Validation Rules

### PMS-Specific Validations
PMS implementations can add custom validation rules:
- Minimum stay requirements
- Maximum occupancy limits
- Rate plan restrictions
- Booking window limitations
- Payment method requirements

### Configuration-Based Rules
Some validations can be configured per hotel:
- Minimum booking advance time
- Maximum length of stay
- Check-in/check-out time restrictions
- Cancellation policy rules

### Extensibility
The validation framework supports:
- Custom validators for specific PMS requirements
- Rule configuration per hotel/chain
- Dynamic validation rule updates
- Integration with external validation services