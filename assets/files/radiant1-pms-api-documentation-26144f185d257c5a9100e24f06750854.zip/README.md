# Radiant1 PMS API Documentation

## Overview

This documentation provides comprehensive information for integrating your Property Management System (PMS) with the Radiant1 platform. The API supports both REST and SOAP protocols to ensure compatibility with various PMS implementations.

## Documentation Structure

1. **[API Overview](01-API-Overview.md)** - General information, authentication, and basic concepts
2. **[REST Booking API](02-REST-Booking-API.md)** - Complete REST API documentation for booking management
3. **[REST Statistics API](03-REST-Statistics-API.md)** - REST API documentation for statistics data
4. **[SOAP API](04-SOAP-API.md)** - SOAP API documentation for OTA-compliant integration
5. **[Data Dictionary](05-Data-Dictionary.md)** - Complete field definitions and data specifications
6. **[Business Validation Rules](06-Business-Validation-Rules.md)** - Detailed validation rules and error handling
7. **[Examples](07-Examples.md)** - Comprehensive examples for all scenarios

## Quick Start

### Prerequisites
- Valid Radiant1 API credentials
- Hotel configured in Radiant1 system
- Understanding of your PMS data structure

### Choose Your Integration Method

**REST API** - Recommended for modern PMS systems
- JSON-based requests/responses
- Easier to implement and debug
- Better performance for high-volume operations

**SOAP API** - For OTA-compliant PMS systems
- XML-based requests/responses
- Industry-standard OTA schemas
- Better compatibility with legacy systems

### Key Information Missing in Original Documentation

This documentation addresses several critical gaps found in the original GitBook documentation:

#### Statistics Data Dictionary (Missing 17 fields)
The original documentation was missing these essential statistics fields:
- `roomSold` - Number of rooms sold
- `cancellation` - Number of cancellations
- `noOfBookings` - Number of bookings
- `totalRevenue`, `totalRoomRevenue`, `totalNonRoomRevenue` - Revenue totals
- Detailed revenue breakdown fields (tax, commission, service charges)

#### Booking API Missing Fields
- `additionalNote` - Additional booking information
- `isHotelCollect` - Hotel collect payment flag
- `isComplimentary` and `isHouseUse` - Special stay flags
- Complete guest information (birthDate, gender, address, etc.)

#### Business Validation Rules
- Room status transition rules
- Guest validation requirements
- Rate coverage validation
- Date relationship validation
- Reference data validation

#### Complete Examples
- Multi-room bookings
- Family bookings with children
- Day use bookings
- Complimentary stays
- Error handling scenarios
- Integration patterns

## Getting Started

1. **Read the API Overview** to understand basic concepts
2. **Choose your protocol** (REST or SOAP)
3. **Review the Data Dictionary** for field specifications
4. **Study the Business Validation Rules** to avoid common errors
5. **Use the Examples** as templates for your integration
6. **Test with development environment** before production deployment

## Support

For technical support and API integration assistance:
- **Email**: api-support@radiant1.com
- **Documentation**: https://docs.radiant1.com
- **Status Page**: https://status.radiant1.com

## Version History

This documentation is based on analysis of the pms-boilerplate codebase and comparison with actual PMS implementations (gustodian, vhp, ids). It provides complete and accurate information for successful API integration.

### What's Included
- Complete field definitions for all API endpoints
- Real business validation rules from the reservation service
- Comprehensive examples covering all scenarios
- Error handling and troubleshooting information
- Integration best practices

### Key Improvements
- Fixed missing statistics data dictionary (17 revenue fields)
- Added complete booking field specifications
- Documented business logic validation rules
- Provided working examples for all scenarios
- Included integration patterns and error handling

---

**Last Updated**: January 2025
**Version**: 2.1.0
**Based on**: pms-boilerplate codebase analysis and production PMS implementations